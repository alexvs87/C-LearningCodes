using System;

namespace Modulo1.Pets
{
    public class Gato : Animal
    {
        public Gato(string nome, int idade) : base(nome, idade)
        {

        }

        public override void Comer()
        {
            Console.WriteLine("Gato comendo..");
            while (Fome >= 0)
            {
                if (Fome < 5)
                {
                    Fome = 0;
                    break;
                }

                Fome -= 5;
                Console.WriteLine("Fome do gato: " + Fome);
            }
        }
    }
}