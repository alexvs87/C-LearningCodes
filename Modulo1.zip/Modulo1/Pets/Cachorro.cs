using System;

namespace Modulo1.Pets
{
    public class Cachorro : Animal
    {
        public Cachorro(string nome, int idade) : base(nome, idade)
        {

        }

        public override void Comer()
        {
            Console.WriteLine("Cachorro comendo..");
            while (Fome >= 0)
            {
                if (Fome < 15)
                {
                    Fome = 0;
                    break;
                }

                Fome -= 15;
                Console.WriteLine("Fome do cachorro: " + Fome);
            }
        }
    }
}