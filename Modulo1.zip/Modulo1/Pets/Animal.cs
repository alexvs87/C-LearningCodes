namespace Modulo1.Pets
{
    public abstract class Animal
    {
        public string Nome { get; set; }
        public int Idade { get; set; }
        public int Fome { get; set; }

        public Animal(string nome, int idade)
        {
            Nome = nome;
            Idade = idade;
            Fome = 100;
        }

        public abstract void Comer();
    }
}