using System;
namespace Modulo1.DecBinCompl
{
    public class DecBin
    {
        public int Number{get ; set;}

        public string DectoBin(int number)
        {
            string Sbin= " ";

            while(number>0)
            {
                
                if(number%2==0)
                {
                    Sbin = '0'+Sbin;        
                }
                else
                {
                    Sbin = '1'+Sbin;    
                }
                number = number/2;
            }
            
            return Sbin;

        }
        public string complement(string wordBin)
        {
            
            var Sbin = "";
            foreach(var digito in wordBin)
            {
                if (digito == '1')
                {
                    Sbin = Sbin+'0';

                }               
                else if (digito == '0')
                {
                    Sbin =  Sbin+'1';
                }

            }
            return Sbin;
        }
        public double BintoDec(string number)
        {
            double dec = 0;
            int mask =1;
            mask = mask*(number.Length-1);
            foreach (var deci in number)
            {
                
                if (deci=='1')
                {
                     mask = mask-1;
                    dec = Math.Pow(2, mask)+dec;
                    
                } 
                else if (deci=='0')
                {
                   // dec = dec*10;
                    mask = mask-1;
                }
                      
            }

            return dec;
        }
    }
}