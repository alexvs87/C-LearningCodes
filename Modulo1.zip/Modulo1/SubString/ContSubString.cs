using System;



namespace Modulo1.SubString
{
    public class ContSubString
    {
        public string PatternSubString(string Word)
        {
            int cont = 0;
            var Sbin = "";
            var WordTemp = Word;
            foreach(var letra in WordTemp)
            {
              foreach(var letraj in Word)
              {
                    if (letraj == letra)
                    {
                          Sbin = Sbin + letra;
                    }
                    else
                    {
                      
                    }
                    cont++;
            }  
            cont =0;
            }

            return Sbin;
        }
        
    }
}