namespace Modulo1.Veiculos
{
    public class Carro : Veiculo
    {
        public bool ArCondicionado { get; set; }

        public Carro(string nome, int ano) : base(nome, ano)
        {
            ArCondicionado = false;
        }

        public Carro(string nome, int ano, decimal valor, bool arCondicionado) : base(nome, ano, valor)
        {
            ArCondicionado = arCondicionado;
        }

        public override string ToString() 
        {
            return base.ToString() + " " + ArCondicionado;
        }
    }
}