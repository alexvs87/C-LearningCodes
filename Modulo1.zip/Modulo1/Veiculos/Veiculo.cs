namespace Modulo1.Veiculos
{
    public abstract class Veiculo
    {
        public string Nome { get; set; }
        public int Ano { get; set; }
        public decimal Valor { get; set; }

        public Veiculo(string nome, int ano)
        {
            Nome = nome;
            Ano = ano;
            Valor = (decimal)5000.75;
        }

        public Veiculo(string nome, int ano, decimal valor)
        {
            Nome = nome;
            Ano = ano;
            Valor = valor;
        }
        
        public override string ToString()
        {
            return Nome + " " + Ano + " " + Valor;
        }
    }
}