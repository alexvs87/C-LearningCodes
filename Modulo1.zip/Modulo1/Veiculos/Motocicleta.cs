namespace Modulo1.Veiculos
{
    public class Motocicleta : Veiculo
    {

        public Motocicleta(string nome, int ano) : base(nome, ano)
        {

        }

        public Motocicleta(string nome, int ano, decimal valor) : base(nome, ano, valor)
        {

        }

        public override string ToString()
        {
            return Nome + " " + Ano;
        }
    }
}