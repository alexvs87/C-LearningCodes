using System.Collections.Generic;
using Modulo1.Veiculos;
using Modulo1.Pets;

namespace Modulo1
{

    public class Pessoa
    {
        public string Nome { get; set; }
        public int Idade { get; set; }
        public List<Veiculo> Veiculos { get; private set; }
        public List<Animal> Animais { get; set; }


        public Pessoa()
        {
            Veiculos = new List<Veiculo>();
            Animais = new List<Animal>();
        }

        public Pessoa(string nome, int idade) : this()
        {
            SetDados(nome, idade);
        }

        public Pessoa(string nome, int idade, Veiculo veiculo) : this(nome, idade)
        {
            AddVeiculo(veiculo);
        }

        public string GetDados()
        {
            var strRetorno = $"{Nome}, {Idade} anos.";
            if (Veiculos != null)
            {
                strRetorno += " / Informações dos veiculos: ";
                foreach (var veiculo in Veiculos)
                {
                    strRetorno +=  $"{veiculo.Nome}, {veiculo.Ano}, {veiculo.Valor} / ";
                }
            }

            if (Animais != null)
            {
                strRetorno += " / Informações dos animais: ";
                foreach (var animal in Animais)
                {
                    strRetorno += $"{animal.Nome}, {animal.Idade}, {animal.Fome} / ";
                }
            }

            return strRetorno;
        }

        public void SetDados(string nome, int idade)
        {
            Nome = nome;
            Idade = idade;
        }

        public void AddIdade(int idade)
        {
            if (idade < 0)
                return;

            Idade = idade;
        }

        public void AddVeiculo(Veiculo veiculo)
        {
            Veiculos.Add(veiculo);
        }

        public void AddVeiculo(List<Veiculo> veiculos)
        {
            Veiculos.AddRange(veiculos);
        }

        public void AddVeiculo(Veiculo[] veiculos)
        {
            Veiculos.AddRange(veiculos);
        }

        public void AddAnimal(Animal animal)
        {
            Animais.Add(animal);
        }

        public void AddAnimal(List<Animal> animais)
        {
            Animais.AddRange(animais);
        }

        public override string ToString()
        {
            return GetDados();
        }
    }
}