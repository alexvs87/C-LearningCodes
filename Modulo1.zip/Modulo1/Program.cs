﻿using System;
using System.Collections.Generic;
using Modulo1.Veiculos;
using Modulo1.Pets;
using Modulo1.DecBinCompl;
using Modulo1.SubString;


namespace  Modulo1 
{
    class Program
    {
        static void Main(string[] args)
        {

            var pessoa1 = new Pessoa();
            var decBin = new DecBin();
            var FPattern = new ContSubString();

            decBin.Number = 29;
            

            pessoa1.Nome = "Lucas";
            pessoa1.Idade = 26;

           // var binario = new DecBin.DectoBin(29);
            var carro1 = new Carro("Ford Ka", 2018, (decimal)30000.50, true);
            var motocicleta1 = new Motocicleta("Ybr", 2013, (decimal)5000.00);

            pessoa1.AddVeiculo(carro1);
            pessoa1.AddVeiculo(motocicleta1);

            var cachorro1 = new Cachorro("Jorginho", 10);
            var gato1 = new Gato("Tonico", 7);

            pessoa1.AddAnimal(cachorro1);
            pessoa1.AddAnimal(gato1);

            gato1.Comer();
            cachorro1.Comer();

            Console.WriteLine(pessoa1.GetDados());

            string name = "Joe";
            string greatings = "Hi " + name;
            Console.WriteLine(greatings);

            string greeting = "Hi " + name.ToUpper(); // Result: greeting = "Hi JOE"
            greeting = greeting.Replace("Hi", "Hello");// Result: greeting = "Hello JOE"

            string songLyrics = "You say goodbye, and I say hello";
            Console.WriteLine(songLyrics.Contains("goodbye"));
            Console.WriteLine(songLyrics.Contains("greetings"));

            songLyrics = "You say goodbye, and I say hello";
            Console.WriteLine(songLyrics.StartsWith("You"));
            Console.WriteLine(songLyrics.StartsWith("goodbye"));

            Console.WriteLine(songLyrics.EndsWith("hello"));
            Console.WriteLine(songLyrics.EndsWith("goodbye"));

            int max = int.MaxValue;
            int min = int.MinValue;
            Console.WriteLine($"The range of integers is {min} to {max}");

            int what = max + 3;
            Console.WriteLine($"An example of overflow: {what}");

            double radius = 2.50;
            double area = Math.PI * radius * radius;
            Console.WriteLine(area);

            int a = 5;
            a = 5;
            int b = 3;
            if (a + b > 10)
            {
                Console.WriteLine("The answer is greater than 10");
            }
            else
            {
                Console.WriteLine("The answer is not greater than 10");
            }


            var nombre = new List<string> { "Alex", "Melissa", "Ana" };
            foreach (var nAme in nombre)
            {
                Console.WriteLine($"Hello {nAme.ToUpper()}!");
            }
            Console.WriteLine();
            nombre.Add("Maria");
            nombre.Add("Bill");
            nombre.Remove("Ana");
            foreach (var nAme in nombre)
            {
                Console.WriteLine($"Hello {nAme.ToUpper()}!");
            }

            Console.WriteLine($"My name is {nombre[0]}.");
            Console.WriteLine($"I've added {nombre[2]} and {nombre[1]} to the list.");

            Console.WriteLine($"The list has {nombre.Count} people in it");

            var index = nombre.IndexOf("Felipe");
            if (index != -1)
                Console.WriteLine($"The name {nombre[index]} is at index {index}");

            var notFound = nombre.IndexOf("Not Found");
            Console.WriteLine($"When an item is not found, IndexOf returns {notFound}");

            Console.WriteLine();
            Console.WriteLine("Lista Ordenada");

            nombre.Sort();
            foreach (var nAme in nombre)
            {
                Console.WriteLine($"Hello {nAme.ToUpper()}!");
            }


            var fibonacciNumbers = new List<int> { 1, 1 };

            while (fibonacciNumbers.Count < 20)
            {
                var previous = fibonacciNumbers[fibonacciNumbers.Count - 1];
                var previous2 = fibonacciNumbers[fibonacciNumbers.Count - 2];

                fibonacciNumbers.Add(previous + previous2);
            }
            foreach (var item in fibonacciNumbers)
            {
                Console.Write(item);
                Console.Write(", ");
            }
            Console.WriteLine("");
            Console.WriteLine(decBin.DectoBin(58));

             Console.WriteLine(decBin.complement(decBin.DectoBin(58)));
            
            Console.WriteLine(decBin.BintoDec(decBin.DectoBin(58)));



            Console.WriteLine(FPattern.PatternSubString("Teste"));
        }
    }
}
